#ifndef __DM510_MSGBOX_H__
#define __DM510_MSGBOX_H__

extern int dm510_msgbox_put( char*, int );
extern int dm510_msgbox_get( char*, int );

#endif
